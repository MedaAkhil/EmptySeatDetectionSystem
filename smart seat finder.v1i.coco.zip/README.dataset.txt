# smart seat finder > 2025-01-14 8:57pm
https://universe.roboflow.com/smart-seater-finder/smart-seat-finder

Provided by a Roboflow user
License: CC BY 4.0

